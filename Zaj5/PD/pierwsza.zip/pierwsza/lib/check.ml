let czy_pierwsza2 n = 
  if n <= 1 then false
  else Commons.czy_pierwsza Primes.l n